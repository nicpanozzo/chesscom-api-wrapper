# from src.chessplayer import ChessPlayer
# from src.chessclub import Club




class PlayerClub(object):
    
    
    def __init__(self, clubname, joined) -> None:
        self.name = clubname
        self.joined = joined

    
    

