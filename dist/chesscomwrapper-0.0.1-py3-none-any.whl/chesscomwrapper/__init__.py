# set version
from .version import __version__
from .src.chesswrapper import ChessWrapper
